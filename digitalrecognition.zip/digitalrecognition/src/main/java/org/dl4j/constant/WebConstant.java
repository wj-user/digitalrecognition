package org.dl4j.constant;

public class WebConstant {
	public static String WEB_ROOT=null;
}
